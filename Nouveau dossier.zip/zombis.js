(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"zombis_atlas_1", frames: [[0,0,1056,1920]]},
		{name:"zombis_atlas_2", frames: [[1148,0,800,1028],[0,888,700,464],[702,1030,470,340],[0,0,1146,886]]}
];


(lib.AnMovieClip = function(){
	this.currentSoundStreamInMovieclip;
	this.actionFrames = [];
	this.soundStreamDuration = new Map();
	this.streamSoundSymbolsList = [];

	this.gotoAndPlayForStreamSoundSync = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.gotoAndPlay = function(positionOrLabel){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(positionOrLabel);
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(this.currentFrame);
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
		this.clearAllSoundStreams();
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
		this.clearAllSoundStreams();
	}
	this.startStreamSoundsForTargetedFrame = function(targetFrame){
		for(var index=0; index<this.streamSoundSymbolsList.length; index++){
			if(index <= targetFrame && this.streamSoundSymbolsList[index] != undefined){
				for(var i=0; i<this.streamSoundSymbolsList[index].length; i++){
					var sound = this.streamSoundSymbolsList[index][i];
					if(sound.endFrame > targetFrame){
						var targetPosition = Math.abs((((targetFrame - sound.startFrame)/lib.properties.fps) * 1000));
						var instance = playSound(sound.id);
						var remainingLoop = 0;
						if(sound.offset){
							targetPosition = targetPosition + sound.offset;
						}
						else if(sound.loop > 1){
							var loop = targetPosition /instance.duration;
							remainingLoop = Math.floor(sound.loop - loop);
							if(targetPosition == 0){ remainingLoop -= 1; }
							targetPosition = targetPosition % instance.duration;
						}
						instance.loop = remainingLoop;
						instance.position = Math.round(targetPosition);
						this.InsertIntoSoundStreamData(instance, sound.startFrame, sound.endFrame, sound.loop , sound.offset);
					}
				}
			}
		}
	}
	this.InsertIntoSoundStreamData = function(soundInstance, startIndex, endIndex, loopValue, offsetValue){ 
 		this.soundStreamDuration.set({instance:soundInstance}, {start: startIndex, end:endIndex, loop:loopValue, offset:offsetValue});
	}
	this.clearAllSoundStreams = function(){
		var keys = this.soundStreamDuration.keys();
		for(var i = 0;i<this.soundStreamDuration.size; i++){
			var key = keys.next().value;
			key.instance.stop();
		}
 		this.soundStreamDuration.clear();
		this.currentSoundStreamInMovieclip = undefined;
	}
	this.stopSoundStreams = function(currentFrame){
		if(this.soundStreamDuration.size > 0){
			var keys = this.soundStreamDuration.keys();
			for(var i = 0; i< this.soundStreamDuration.size ; i++){
				var key = keys.next().value; 
				var value = this.soundStreamDuration.get(key);
				if((value.end) == currentFrame){
					key.instance.stop();
					if(this.currentSoundStreamInMovieclip == key) { this.currentSoundStreamInMovieclip = undefined; }
					this.soundStreamDuration.delete(key);
				}
			}
		}
	}

	this.computeCurrentSoundStreamInstance = function(currentFrame){
		if(this.currentSoundStreamInMovieclip == undefined){
			if(this.soundStreamDuration.size > 0){
				var keys = this.soundStreamDuration.keys();
				var maxDuration = 0;
				for(var i=0;i<this.soundStreamDuration.size;i++){
					var key = keys.next().value;
					var value = this.soundStreamDuration.get(key);
					if(value.end > maxDuration){
						maxDuration = value.end;
						this.currentSoundStreamInMovieclip = key;
					}
				}
			}
		}
	}
	this.getDesiredFrame = function(currentFrame, calculatedDesiredFrame){
		for(var frameIndex in this.actionFrames){
			if((frameIndex > currentFrame) && (frameIndex < calculatedDesiredFrame)){
				return frameIndex;
			}
		}
		return calculatedDesiredFrame;
	}

	this.syncStreamSounds = function(){
		this.stopSoundStreams(this.currentFrame);
		this.computeCurrentSoundStreamInstance(this.currentFrame);
		if(this.currentSoundStreamInMovieclip != undefined){
			var soundInstance = this.currentSoundStreamInMovieclip.instance;
			if(soundInstance.position != 0){
				var soundValue = this.soundStreamDuration.get(this.currentSoundStreamInMovieclip);
				var soundPosition = (soundValue.offset?(soundInstance.position - soundValue.offset): soundInstance.position);
				var calculatedDesiredFrame = (soundValue.start)+((soundPosition/1000) * lib.properties.fps);
				if(soundValue.loop > 1){
					calculatedDesiredFrame +=(((((soundValue.loop - soundInstance.loop -1)*soundInstance.duration)) / 1000) * lib.properties.fps);
				}
				calculatedDesiredFrame = Math.floor(calculatedDesiredFrame);
				var deltaFrame = calculatedDesiredFrame - this.currentFrame;
				if(deltaFrame >= 2){
					this.gotoAndPlayForStreamSoundSync(this.getDesiredFrame(this.currentFrame,calculatedDesiredFrame));
				}
			}
		}
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Imagebitmap11 = function() {
	this.initialize(ss["zombis_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Imagebitmap34 = function() {
	this.initialize(ss["zombis_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Imagebitmap10 = function() {
	this.initialize(ss["zombis_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.unnamed2 = function() {
	this.initialize(ss["zombis_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["zombis_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbole5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Imagebitmap10();
	this.instance.setTransform(0,0,0.0606,0.0657);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole5, new cjs.Rectangle(0,0,64,126.2), null);


(lib.Symbole1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Imagebitmap11();
	this.instance.setTransform(0,0,0.0556,0.0556);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole1, new cjs.Rectangle(0,0,44.5,57.2), null);


(lib.Interpoler1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Imagebitmap34();
	this.instance.setTransform(-286,-231,0.8012,0.9178);

	this.instance_1 = new lib.CachedBmp_8();
	this.instance_1.setTransform(-286.5,-211.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-286.5,-231,573,462.6);


(lib.Ak47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.unnamed2();
	this.instance.setTransform(0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ak47, new cjs.Rectangle(0,0,141,102), null);


// stage content:
(lib.Sansnom4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{gun:49});

	this.actionFrames = [0,49];
	// timeline functions:
	this.frame_0 = function() {
		this.clearAllSoundStreams();
		 
	}
	this.frame_49 = function() {
		var _this = this;
		/*
		Cliquez sur l’occurrence de symbole spécifiée pour exécuter une fonction.
		*/
		_this.Z1.on('click', function(){
		/*
		Pour déplacer l’occurrence de symbole spécifiée vers la gauche ou vers la droite, il convient de diminuer ou d’augmenter la valeur de sa propriété x du nombre de pixels spécifié.
		Pour déplacer une occurrence à gauche, saisissez un nombre négatif.
		*/
		_this.Z1.x+=20000;
		});
		
		
		var _this = this;
		/*
		Cliquez sur l’occurrence de symbole spécifiée pour exécuter une fonction.
		*/
		_this.Z2.on('click', function(){
		/*
		Pour déplacer l’occurrence de symbole spécifiée vers la gauche ou vers la droite, il convient de diminuer ou d’augmenter la valeur de sa propriété x du nombre de pixels spécifié.
		Pour déplacer une occurrence à gauche, saisissez un nombre négatif.
		*/
		_this.Z2.x+=20000;
		});
		
		
		var _this = this;
		/*
		Cliquez sur l’occurrence de symbole spécifiée pour exécuter une fonction.
		*/
		_this.Z3.on('click', function(){
		/*
		Pour déplacer l’occurrence de symbole spécifiée vers la gauche ou vers la droite, il convient de diminuer ou d’augmenter la valeur de sa propriété x du nombre de pixels spécifié.
		Pour déplacer une occurrence à gauche, saisissez un nombre négatif.
		*/
		_this.Z3.x+=20000;
		});
		
		
		var _this = this;
		/*
		Cliquez sur l’occurrence de symbole spécifiée pour exécuter une fonction.
		*/
		_this.Z4.on('click', function(){
		/*
		Pour déplacer l’occurrence de symbole spécifiée vers la gauche ou vers la droite, il convient de diminuer ou d’augmenter la valeur de sa propriété x du nombre de pixels spécifié.
		Pour déplacer une occurrence à gauche, saisissez un nombre négatif.
		*/
		_this.Z4.x+=20000;
		});
		
		
		var _this = this;
		/*
		Cliquez sur l’occurrence de symbole spécifiée pour exécuter une fonction.
		*/
		_this.Z5.on('click', function(){
		/*
		Charge l’URL dans une nouvelle fenêtre du navigateur.
		*/
		window.open('https://www.donneurdesang.be/fr/qui-peut-donner/puis-je-donner', '_blank');
		});
		
		stage.on('stagemousemove', function (e) {
			var radians = Math.atan2(e.localY - _this.gun.y, e.localX - _this.gun.x);
			var degrees = radians * (180 / Math.PI);
			_this.gun.rotation = degrees - 0;
		});
		
		
		
		var _this = this;
		/*
		Déplace la tête de lecture jusqu’à l’étiquette d’image spécifiée dans le scénario et arrête le clip.
		Ce code peut être utilisé sur le scénario principal ou sur les scénarios des clips.
		*/
		_this.gotoAndStop('enterFrameLabel');
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(1));

	// Calque_10
	this.text = new cjs.Text("1    4     5   2    3", "24px 'Playbill'", "#FFFFFF");
	this.text.lineHeight = 26;
	this.text.lineWidth = 188;
	this.text.parent = this;
	this.text.setTransform(326,373.2);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(48).to({_off:false},0).wait(2));

	// Titre
	this.text_1 = new cjs.Text("Cliquez sur les zombis pour les faire disparaître !", "36px 'Playbill'");
	this.text_1.lineHeight = 38;
	this.text_1.lineWidth = 440;
	this.text_1.parent = this;
	this.text_1.setTransform(-455.95,27.1);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1).to({x:-446.4204},0).wait(1).to({x:-436.8908},0).wait(1).to({x:-427.3612},0).wait(1).to({x:-417.8316},0).wait(1).to({x:-408.302},0).wait(1).to({x:-398.7724},0).wait(1).to({x:-389.2429},0).wait(1).to({x:-379.7133},0).wait(1).to({x:-370.1837},0).wait(1).to({x:-360.6541},0).wait(1).to({x:-351.1245},0).wait(1).to({x:-341.5949},0).wait(1).to({x:-332.0653},0).wait(1).to({x:-322.5357},0).wait(1).to({x:-313.0061},0).wait(1).to({x:-303.4765},0).wait(1).to({x:-293.9469},0).wait(1).to({x:-284.4173},0).wait(1).to({x:-274.8878},0).wait(1).to({x:-265.3582},0).wait(1).to({x:-255.8286},0).wait(1).to({x:-246.299},0).wait(1).to({x:-236.7694},0).wait(1).to({x:-227.2398},0).wait(1).to({x:-217.7102},0).wait(1).to({x:-208.1806},0).wait(1).to({x:-198.651},0).wait(1).to({x:-189.1214},0).wait(1).to({x:-179.5918},0).wait(1).to({x:-170.0622},0).wait(1).to({x:-160.5327},0).wait(1).to({x:-151.0031},0).wait(1).to({x:-141.4735},0).wait(1).to({x:-131.9439},0).wait(1).to({x:-122.4143},0).wait(1).to({x:-112.8847},0).wait(1).to({x:-103.3551},0).wait(1).to({x:-93.8255},0).wait(1).to({x:-84.2959},0).wait(1).to({x:-74.7663},0).wait(1).to({x:-65.2367},0).wait(1).to({x:-55.7071},0).wait(1).to({x:-46.1776},0).wait(1).to({x:-36.648},0).wait(1).to({x:-27.1184},0).wait(1).to({x:-17.5888},0).wait(1).to({x:-8.0592},0).wait(1).to({x:1.4704},0).wait(1).to({x:11},0).wait(1));

	// gun
	this.gun = new lib.Ak47();
	this.gun.name = "gun";
	this.gun.setTransform(52.5,348,0.3767,0.3767,0,0,0,70.5,51);

	this.timeline.addTween(cjs.Tween.get(this.gun).wait(50));

	// MC
	this.instance = new lib.Symbole1();
	this.instance.setTransform(38.45,338.65,1,1,0,0,0,22.2,28.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(50));

	// Z5
	this.Z5 = new lib.Symbole5();
	this.Z5.name = "Z5";
	this.Z5.setTransform(712.95,373,0.5367,0.5262,0,0,6.6759,27.4,60.4);
	new cjs.ButtonHelper(this.Z5, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.Z5).wait(1).to({regX:32,regY:63.1,skewY:6.6778,x:709.15,y:373.5},0).wait(1).to({x:702.9,y:372.3},0).wait(1).to({x:696.65,y:371.15},0).wait(1).to({x:690.4,y:370},0).wait(1).to({x:684.15,y:368.8},0).wait(1).to({x:677.9,y:367.65},0).wait(1).to({x:671.65,y:366.45},0).wait(1).to({x:665.4,y:365.3},0).wait(1).to({x:659.15,y:364.1},0).wait(1).to({x:652.9,y:362.95},0).wait(1).to({x:646.65,y:361.75},0).wait(1).to({x:640.4,y:360.6},0).wait(1).to({x:634.15,y:359.4},0).wait(1).to({x:627.9,y:358.25},0).wait(1).to({x:621.65,y:357.05},0).wait(1).to({x:615.4,y:355.9},0).wait(1).to({x:609.15,y:354.7},0).wait(1).to({x:602.9,y:353.55},0).wait(1).to({x:596.65,y:352.35},0).wait(1).to({x:590.4,y:351.2},0).wait(1).to({x:584.15,y:350},0).wait(1).to({x:577.9,y:348.85},0).wait(1).to({x:571.65,y:347.65},0).wait(1).to({x:565.4,y:346.5},0).wait(1).to({x:559.15,y:345.3},0).wait(1).to({x:552.9,y:344.15},0).wait(1).to({x:546.65,y:342.95},0).wait(1).to({x:540.4,y:341.8},0).wait(1).to({x:534.15,y:340.6},0).wait(1).to({x:527.9,y:339.45},0).wait(1).to({x:521.65,y:338.25},0).wait(1).to({x:515.4,y:337.1},0).wait(1).to({x:509.15,y:335.9},0).wait(1).to({x:502.9,y:334.75},0).wait(1).to({x:496.65,y:333.55},0).wait(1).to({x:490.4,y:332.4},0).wait(1).to({x:484.15,y:331.2},0).wait(1).to({x:477.9,y:330.05},0).wait(1).to({x:471.65,y:328.85},0).wait(1).to({x:465.4,y:327.7},0).wait(1).to({x:459.15,y:326.5},0).wait(1).to({x:452.9,y:325.35},0).wait(1).to({x:446.65,y:324.15},0).wait(1).to({x:440.4,y:323},0).wait(1).to({x:434.15,y:321.8},0).wait(1).to({x:427.9,y:320.65},0).wait(1).to({x:421.65,y:319.45},0).wait(1).to({x:415.4,y:318.3},0).wait(1).to({x:409.15,y:317.1},0).wait(1));

	// Z4
	this.Z4 = new lib.Symbole5();
	this.Z4.name = "Z4";
	this.Z4.setTransform(690.95,354,0.5367,0.5262,0,0,6.6759,27.4,62.1);
	new cjs.ButtonHelper(this.Z4, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.Z4).wait(1).to({regX:32,regY:63.1,skewY:6.6778,x:686.7,y:354.35},0).wait(1).to({x:680.05,y:353.9},0).wait(1).to({x:673.4,y:353.45},0).wait(1).to({x:666.75,y:352.95},0).wait(1).to({x:660.1,y:352.5},0).wait(1).to({x:653.45,y:352.05},0).wait(1).to({x:646.8,y:351.6},0).wait(1).to({x:640.15,y:351.1},0).wait(1).to({x:633.5,y:350.65},0).wait(1).to({x:626.8,y:350.2},0).wait(1).to({x:620.15,y:349.75},0).wait(1).to({x:613.5,y:349.25},0).wait(1).to({x:606.85,y:348.8},0).wait(1).to({x:600.2,y:348.35},0).wait(1).to({x:593.55,y:347.85},0).wait(1).to({x:586.9,y:347.4},0).wait(1).to({x:580.25,y:346.95},0).wait(1).to({x:573.6,y:346.5},0).wait(1).to({x:566.95,y:346},0).wait(1).to({x:560.25,y:345.55},0).wait(1).to({x:553.6,y:345.1},0).wait(1).to({x:546.95,y:344.65},0).wait(1).to({x:540.3,y:344.15},0).wait(1).to({x:533.65,y:343.7},0).wait(1).to({x:527,y:343.25},0).wait(1).to({x:520.35,y:342.8},0).wait(1).to({x:513.7,y:342.3},0).wait(1).to({x:507.05,y:341.85},0).wait(1).to({x:500.4,y:341.4},0).wait(1).to({x:493.7,y:340.95},0).wait(1).to({x:487.05,y:340.45},0).wait(1).to({x:480.4,y:340},0).wait(1).to({x:473.75,y:339.55},0).wait(1).to({x:467.1,y:339.05},0).wait(1).to({x:460.45,y:338.6},0).wait(1).to({x:453.8,y:338.15},0).wait(1).to({x:447.15,y:337.7},0).wait(1).to({x:440.5,y:337.2},0).wait(1).to({x:433.85,y:336.75},0).wait(1).to({x:427.15,y:336.3},0).wait(1).to({x:420.5,y:335.85},0).wait(1).to({x:413.85,y:335.35},0).wait(1).to({x:407.2,y:334.9},0).wait(1).to({x:400.55,y:334.45},0).wait(1).to({x:393.9,y:334},0).wait(1).to({x:387.25,y:333.5},0).wait(1).to({x:380.6,y:333.05},0).wait(1).to({x:373.95,y:332.6},0).wait(1).to({x:367.25,y:332.1},0).wait(1));

	// Z3
	this.Z3 = new lib.Symbole5();
	this.Z3.name = "Z3";
	this.Z3.setTransform(692.95,340,0.5367,0.5262,0,0,6.6759,27.4,62.1);
	new cjs.ButtonHelper(this.Z3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.Z3).wait(1).to({regX:32,regY:63.1,skewY:6.6778,x:690.9,y:340.35},0).wait(1).to({x:686.45,y:339.85},0).wait(1).to({x:681.95,y:339.4},0).wait(1).to({x:677.5,y:338.9},0).wait(1).to({x:673,y:338.45},0).wait(1).to({x:668.55,y:337.95},0).wait(1).to({x:664.05,y:337.45},0).wait(1).to({x:659.6,y:337},0).wait(1).to({x:655.1,y:336.5},0).wait(1).to({x:650.65,y:336.05},0).wait(1).to({x:646.15,y:335.55},0).wait(1).to({x:641.7,y:335.1},0).wait(1).to({x:637.2,y:334.6},0).wait(1).to({x:632.75,y:334.1},0).wait(1).to({x:628.25,y:333.65},0).wait(1).to({x:623.8,y:333.15},0).wait(1).to({x:619.3,y:332.7},0).wait(1).to({x:614.85,y:332.2},0).wait(1).to({x:610.35,y:331.75},0).wait(1).to({x:605.9,y:331.25},0).wait(1).to({x:601.4,y:330.75},0).wait(1).to({x:596.95,y:330.3},0).wait(1).to({x:592.45,y:329.8},0).wait(1).to({x:588,y:329.35},0).wait(1).to({x:583.5,y:328.85},0).wait(1).to({x:579.05,y:328.4},0).wait(1).to({x:574.55,y:327.9},0).wait(1).to({x:570.1,y:327.4},0).wait(1).to({x:565.6,y:326.95},0).wait(1).to({x:561.15,y:326.45},0).wait(1).to({x:556.65,y:326},0).wait(1).to({x:552.2,y:325.5},0).wait(1).to({x:547.7,y:325.05},0).wait(1).to({x:543.25,y:324.55},0).wait(1).to({x:538.75,y:324.05},0).wait(1).to({x:534.3,y:323.6},0).wait(1).to({x:529.8,y:323.1},0).wait(1).to({x:525.35,y:322.65},0).wait(1).to({x:520.85,y:322.15},0).wait(1).to({x:516.4,y:321.7},0).wait(1).to({x:511.9,y:321.2},0).wait(1).to({x:507.45,y:320.7},0).wait(1).to({x:502.95,y:320.25},0).wait(1).to({x:498.5,y:319.75},0).wait(1).to({x:494,y:319.3},0).wait(1).to({x:489.55,y:318.8},0).wait(1).to({x:485.05,y:318.35},0).wait(1).to({x:480.6,y:317.85},0).wait(1).to({x:476.1,y:317.35},0).wait(1));

	// Z2
	this.Z2 = new lib.Symbole5();
	this.Z2.name = "Z2";
	this.Z2.setTransform(648,317.05,0.5367,0.5262,0,0,6.6759,27.4,59.5);
	new cjs.ButtonHelper(this.Z2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.Z2).wait(1).to({regX:32,regY:63.1,skewY:6.6778,x:646.15,y:319.4},0).wait(1).to({x:641.85,y:319.55},0).wait(1).to({x:637.55,y:319.75},0).wait(1).to({x:633.25,y:319.9},0).wait(1).to({x:629,y:320.1},0).wait(1).to({x:624.7,y:320.25},0).wait(1).to({x:620.4,y:320.45},0).wait(1).to({x:616.1,y:320.6},0).wait(1).to({x:611.85,y:320.8},0).wait(1).to({x:607.55,y:320.95},0).wait(1).to({x:603.25,y:321.1},0).wait(1).to({x:598.95,y:321.3},0).wait(1).to({x:594.65,y:321.45},0).wait(1).to({x:590.4,y:321.65},0).wait(1).to({x:586.1,y:321.8},0).wait(1).to({x:581.8,y:322},0).wait(1).to({x:577.5,y:322.15},0).wait(1).to({x:573.25,y:322.35},0).wait(1).to({x:568.95,y:322.5},0).wait(1).to({x:564.65,y:322.65},0).wait(1).to({x:560.35,y:322.85},0).wait(1).to({x:556.05,y:323},0).wait(1).to({x:551.8,y:323.2},0).wait(1).to({x:547.5,y:323.35},0).wait(1).to({x:543.2,y:323.55},0).wait(1).to({x:538.9,y:323.7},0).wait(1).to({x:534.65,y:323.9},0).wait(1).to({x:530.35,y:324.05},0).wait(1).to({x:526.05,y:324.2},0).wait(1).to({x:521.75,y:324.4},0).wait(1).to({x:517.45,y:324.55},0).wait(1).to({x:513.2,y:324.75},0).wait(1).to({x:508.9,y:324.9},0).wait(1).to({x:504.6,y:325.1},0).wait(1).to({x:500.3,y:325.25},0).wait(1).to({x:496.05,y:325.45},0).wait(1).to({x:491.75,y:325.6},0).wait(1).to({x:487.45,y:325.8},0).wait(1).to({x:483.15,y:325.95},0).wait(1).to({x:478.85,y:326.1},0).wait(1).to({x:474.6,y:326.3},0).wait(1).to({x:470.3,y:326.45},0).wait(1).to({x:466,y:326.65},0).wait(1).to({x:461.7,y:326.8},0).wait(1).to({x:457.45,y:327},0).wait(1).to({x:453.15,y:327.15},0).wait(1).to({x:448.85,y:327.35},0).wait(1).to({x:444.55,y:327.5},0).wait(1).to({x:440.25,y:327.65},0).wait(1));

	// Z1
	this.Z1 = new lib.Symbole5();
	this.Z1.name = "Z1";
	this.Z1.setTransform(682.95,358.05,0.5367,0.5262,0,0,6.6759,27.4,60.1);
	new cjs.ButtonHelper(this.Z1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.Z1).wait(1).to({regX:32,regY:63.1,skewY:6.6778,x:678.05,y:359.05},0).wait(1).to({x:670.75,y:358.15},0).wait(1).to({x:663.45,y:357.25},0).wait(1).to({x:656.15,y:356.35},0).wait(1).to({x:648.85,y:355.45},0).wait(1).to({x:641.55,y:354.55},0).wait(1).to({x:634.2,y:353.65},0).wait(1).to({x:626.9,y:352.75},0).wait(1).to({x:619.6,y:351.85},0).wait(1).to({x:612.3,y:350.95},0).wait(1).to({x:605,y:350.05},0).wait(1).to({x:597.7,y:349.15},0).wait(1).to({x:590.35,y:348.25},0).wait(1).to({x:583.05,y:347.35},0).wait(1).to({x:575.75,y:346.45},0).wait(1).to({x:568.45,y:345.55},0).wait(1).to({x:561.15,y:344.7},0).wait(1).to({x:553.85,y:343.8},0).wait(1).to({x:546.5,y:342.9},0).wait(1).to({x:539.2,y:342},0).wait(1).to({x:531.9,y:341.1},0).wait(1).to({x:524.6,y:340.2},0).wait(1).to({x:517.3,y:339.3},0).wait(1).to({x:510,y:338.4},0).wait(1).to({x:502.65,y:337.5},0).wait(1).to({x:495.35,y:336.6},0).wait(1).to({x:488.05,y:335.7},0).wait(1).to({x:480.75,y:334.8},0).wait(1).to({x:473.45,y:333.9},0).wait(1).to({x:466.15,y:333},0).wait(1).to({x:458.8,y:332.1},0).wait(1).to({x:451.5,y:331.2},0).wait(1).to({x:444.2,y:330.3},0).wait(1).to({x:436.9,y:329.45},0).wait(1).to({x:429.6,y:328.55},0).wait(1).to({x:422.3,y:327.65},0).wait(1).to({x:414.95,y:326.75},0).wait(1).to({x:407.65,y:325.85},0).wait(1).to({x:400.35,y:324.95},0).wait(1).to({x:393.05,y:324.05},0).wait(1).to({x:385.75,y:323.15},0).wait(1).to({x:378.45,y:322.25},0).wait(1).to({x:371.1,y:321.35},0).wait(1).to({x:363.8,y:320.45},0).wait(1).to({x:356.5,y:319.55},0).wait(1).to({x:349.2,y:318.65},0).wait(1).to({x:341.9,y:317.75},0).wait(1).to({x:334.6,y:316.85},0).wait(1).to({x:327.25,y:315.95},0).wait(1));

	// Ville
	this.instance_1 = new lib.Interpoler1("synched",0);
	this.instance_1.setTransform(286,213,1,0.9697);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-182.9,189.1,915.4,248.4);
// library properties:
lib.properties = {
	id: 'C3E52E232A6C4A488AC9E531CCB646F8',
	width: 550,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/zombis_atlas_1.png", id:"zombis_atlas_1"},
		{src:"images/zombis_atlas_2.png", id:"zombis_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C3E52E232A6C4A488AC9E531CCB646F8'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;